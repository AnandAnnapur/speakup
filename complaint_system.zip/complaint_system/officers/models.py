"""
Complaint officer and complaint models
"""
from django.db import models
from django.contrib.auth.hashers import make_password, check_password
import uuid
from datetime import datetime, timedelta
from django.utils import timezone

class ComplaintOfficer(models.Model):
    email = models.EmailField(unique=True)
    password_hash = models.CharField(max_length=128)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def set_password(self, password):
        self.password_hash = make_password(password)
    
    def check_password(self, password):
        return check_password(password, self.password_hash)
    
    def __str__(self):
        return self.email

class Complaint(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Ongoing', 'Ongoing'),
        ('Completed', 'Completed'),
    ]

    complaint_id = models.CharField(max_length=12, unique=True, editable=False) # Made unique and non-editable
    username = models.CharField(max_length=150, default='anonymous')
    description = models.TextField()
    password_hash = models.CharField(max_length=128)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Generate complaint_id if it's not already set
        if not self.complaint_id:
            # Generate a unique 12-character ID and convert to uppercase
            self.complaint_id = str(uuid.uuid4()).replace('-', '')[:12].upper()

        # IMPORTANT: The form's save method now handles hashing.
        # This block is kept in the model's save method as per your instruction
        # not to change the model, but it will not be triggered if the form
        # directly sets password_hash.
        if hasattr(self, '_raw_password') and self._raw_password:
            self.password_hash = make_password(self._raw_password)
            self._raw_password = None # Clear the raw password after hashing for security

        super().save(*args, **kwargs)

    def check_password(self, raw_password):
        """
        Returns a boolean of whether the raw_password was correct.
        This method is crucial for verifying the entered password against the stored hash.
        """
        return check_password(raw_password, self.password_hash)

    def __str__(self):
        return f"Complaint {self.complaint_id} - {self.username}"

    @classmethod
    def delete_old_completed(cls):
        """Delete completed complaints older than 1 month."""
        one_month_ago = timezone.now() - timedelta(days=30)
        cls.objects.filter(
            status='Completed',
            created_at__lt=one_month_ago
        ).delete()
