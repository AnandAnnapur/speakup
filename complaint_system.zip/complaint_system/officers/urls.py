"""
URL patterns for the officers app
"""
from django.urls import path
from . import views

urlpatterns = [
    # Redirect root to login
    path('', views.officer_login, name='home'),
    
    # Officer authentication URLs
    path('signup/', views.officer_signup, name='officer_signup'),
    path('login/', views.officer_login, name='officer_login'),
    path('logout/', views.officer_logout, name='officer_logout'),
    
    # Complaint management URLs
    path('dashboard/', views.complaint_dashboard, name='complaint_dashboard'),
    path('complaints/update-status/<int:pk>/', views.update_complaint_status, name='update_complaint_status'),

    path('create/', views.create_complaint, name='create_complaint'),
    path('status/', views.check_status, name='check_status'),
]
